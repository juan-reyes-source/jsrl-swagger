EMPTY = {
    "$schema": "https://json-schema.org/draft/2020-12/schema",
    "$id": "https://example.com/schemas/EMPTY",
    "type": "object",
    "additionalProperties": False
}
